const mongoose = require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/registration").then(()=>{
    console.log("Database Connected")
}).catch((e)=>{
    console.log(e)
    console.log("Database Can't Be Connected")
})


