const express=require("express");
require ("../src/db/conn");
const  FormData=require("../src/models/form");

const app=express();
 const port=process.env.port || 3000;
 app.use(express.json());

app.post("/form", async(req,res) =>{
    try {
        const addingFormRecord=new FormData(req.body);
        console.log(req.body);
     const insertFromData= await addingFormRecord.save();
     res.status(201).send( insertFromData);
    } catch (error) {
        res.status(400).send(error);
    };

});

app.get("/form", async(req,res) =>{
    try {
      const getdata= await  FormData.find({});
     res.send( getdata);
    } catch (error) {
        res.status(400).send(error);
    };

});
 app.listen(port,(req,res) =>{

    console.log(`server starting on port ${port}`);

 });

