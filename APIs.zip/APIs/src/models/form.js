const express=require("express");
const mongoose=require("mongoose");

const stSchema=new mongoose.Schema({
    userName:{
        type:String,
        require:true
    },
    LastName:{
        type:String,
        require:true
    },
    userNumber:{
        type:Number,
        require:true
    },
    userEmail:{
        type:String,
        require:true
    },
    userCourses:{
        type:String,
        require:true
    },
    userHighQualification:{
        type:String,
        require:true
    },
    userYearGraduation:{
        type:String,
        require:true
    },
    userState:{
        type:String,
        require:true
    },
    userObjective:{
        type:String,
        require:true
    },
    userAim:{
        type:String,
        require:true
    }
});

const FormData=new mongoose.model("FormData", stSchema);
module.exports=FormData;